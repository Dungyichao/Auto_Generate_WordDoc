﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Data.SqlClient;
using System.Net.NetworkInformation;
using Word = Microsoft.Office.Interop.Word;
using ZXing.Common;
using ZXing;
using ZXing.QrCode;
using System.Threading;
using System.Diagnostics;
using Microsoft.Win32;
//using Excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        internal string connection_ntsb = "Data Source = 172.254.254.254; Initial Catalog = IN_OUT_DB; Persist Security Info=True;User ID = sa; Password = 123456; Connection Timeout=12";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataSet Check_In_ds = new DataSet();
            string Order_No = string.Empty;
            Order_No = textBox1.Text.ToString();
            string sql_select_str = @"
SELECT TOP 1 
[Create_Time]
,[Order_No]
,[Truck_Company]
,[Plate_No]
,[Plate_State]
,[Trailer_No]
,[Broker]
,[Destination]
,[Destination_State]
,[Driver_Name]
,[Driver_License_No]
,[Driver_License_State]
,[Warehouse]
,[Dock]
,[Created_By]
,[Status]
,[Latest_Version]
  FROM [id4].[dbo].[CarrierCheckIn]
  where Order_No = '{0}' AND Latest_Version = '1'
ORDER BY Create_Time DESC
";
            string sql_select_str_final = string.Format(sql_select_str, Order_No);
            Check_In_ds = Query_database(connection_ntsb, sql_select_str_final);
            if (Table_Has_Rows(Check_In_ds))
            {
                generate_report(Check_In_ds);
            }

            

        }

        public bool PingHost(string nameOrAddress)
        {
            bool pingable = false;
            Ping pinger = null;

            try
            {
                pinger = new Ping();
                PingReply reply = pinger.Send(nameOrAddress);
                pingable = reply.Status == IPStatus.Success;
            }
            catch (PingException)
            {
                // Discard PingExceptions and return false;
            }
            finally
            {
                if (pinger != null)
                {
                    pinger.Dispose();
                }
            }

            return pingable;
        }

        public DataSet Query_database(string conn_str, string query_str)
        {
            DataSet ds = new DataSet();

            if (ds.Tables.Count > 0)
            {

                ds.Tables[0].Columns.Clear();
                ds.Tables[0].Clear();
                ds.Reset();  //I forgot to put this and cause the "Object reference not set to an instance of an object"
                //ds.Tables[0].Rows.Clear();
            }
            //ds.Tables[0].Rows.Clear();
            using (SqlConnection Myconn2 = new SqlConnection(conn_str))
            using (SqlCommand Mycomm2 = new SqlCommand(query_str, Myconn2))
            {
                try
                {
                    Myconn2.Open();
                    SqlDataAdapter MyAd2 = new SqlDataAdapter();
                    MyAd2.SelectCommand = Mycomm2;
                    //DataTable dTable2 = new DataTable();
                    //MyAd2.Fill(dTable2);
                    MyAd2.Fill(ds);
                    Myconn2.Close();
                }
                catch (Exception ex)
                {

                }
            }
            return ds;
        }

        public bool Table_Has_Rows(DataSet ds)
        {
            if (ds.Tables.Count > 0)
            {
                return ds.Tables[0].Rows.Count > 0;
            }
            else
            {
                return false;
            }

        }

        public void generate_report(DataSet ds)
        {
            //Visual Studio, C# how to add a doc file as a resource: 
            //https://stackoverflow.com/questions/15925801/visual-studio-c-sharp-how-to-add-a-doc-file-as-a-resource
            //Using Resource File 
            //https://stackoverflow.com/questions/33164270/how-to-open-embedded-resource-word-document
            String fileName = Path.GetTempFileName();
            String save_fileName = Path.GetTempFileName();
            String QR_save_fileName = Path.GetTempFileName();
            String QR_print_fileName = Path.GetTempFileName();
            File.WriteAllBytes(fileName, Properties.Resources.Customer_Pick_Up_Carrier_Check_In_Sheet_Template);
            object temp_file_name = (object)fileName;
            object temp_save_fileName = (object)save_fileName;

            Word.Application winword = new Word.Application();
            winword.Visible = false;
            object missing = System.Reflection.Missing.Value;
            Word.Document document = winword.Documents.Add(ref temp_file_name, ref missing, ref missing, ref missing);

            string Create_Time = ds.Tables[0].Rows[0]["Create_Time"].ToString();
            string Order_No = ds.Tables[0].Rows[0]["Order_No"].ToString();
            string Truck_Company = ds.Tables[0].Rows[0]["Truck_Company"].ToString();
            string Plate_No = ds.Tables[0].Rows[0]["Plate_No"].ToString();
            string Plate_State = ds.Tables[0].Rows[0]["Plate_State"].ToString();
            string Trailer_No = ds.Tables[0].Rows[0]["Trailer_No"].ToString();
            string Broker = ds.Tables[0].Rows[0]["Broker"].ToString();
            string Destination = ds.Tables[0].Rows[0]["Destination"].ToString();
            string Destination_State = ds.Tables[0].Rows[0]["Destination_State"].ToString();
            string Driver_Name = ds.Tables[0].Rows[0]["Driver_Name"].ToString();
            string Driver_License_No = ds.Tables[0].Rows[0]["Driver_License_No"].ToString();
            string Driver_License_State = ds.Tables[0].Rows[0]["Driver_License_State"].ToString();
            string Warehouse = ds.Tables[0].Rows[0]["Warehouse"].ToString();
            string Dock = ds.Tables[0].Rows[0]["Dock"].ToString();
            string Status = ds.Tables[0].Rows[0]["Status"].ToString();
            string Latest_Version = ds.Tables[0].Rows[0]["Latest_Version"].ToString();

            //https://www.codeproject.com/Articles/1005081/Basic-with-QR-Code-using-Zxing-Library
            
            QrCodeEncodingOptions options = new QrCodeEncodingOptions();
            options = new QrCodeEncodingOptions
            {
                DisableECI = true,
                CharacterSet = "UTF-8",
                Width = 150,
                Height = 150,
            };
            var qr = new ZXing.BarcodeWriter();
            qr.Options = options;
            qr.Format = ZXing.BarcodeFormat.QR_CODE;
            string QR_str = string.Format("{0},{1},{2}", Order_No, Trailer_No, Dock);
            var result = new Bitmap(qr.Write(QR_str));
            result.Save(QR_save_fileName);

            foreach (Word.Field myMergeField in document.Fields)
            {
                Word.Range rngFieldCode = myMergeField.Code;

                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {
                    Int32 endMerge = fieldText.IndexOf("\\");

                    Int32 fieldNameLength = fieldText.Length - endMerge;

                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName == "Create_Time")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Create_Time);
                    }
                    else if (fieldName == "Order_No")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Order_No);
                    }
                    else if (fieldName == "Truck_Company")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Truck_Company);
                    }
                    else if (fieldName == "Plate_No")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Plate_No);
                    }
                    else if (fieldName == "Plate_State")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Plate_State);
                    }
                    else if (fieldName == "Trailer_No")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Trailer_No);
                    }
                    else if (fieldName == "Broker")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Broker);
                    }
                    else if (fieldName == "Destination")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Destination);
                    }
                    else if (fieldName == "Destination_State")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Destination_State);
                    }
                    else if (fieldName == "Driver_Name")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Driver_Name);
                    }
                    else if (fieldName == "Driver_License_No")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Driver_License_No);
                    }
                    else if (fieldName == "Driver_License_State")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Driver_License_State);
                    }
                    else if (fieldName == "Dock")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(Dock);
                    }
                    else if (fieldName == "QR_str")
                    {
                        myMergeField.Select();
                        winword.Selection.TypeText(QR_str);
                    }
                    else if (fieldName == "QR_CODE")
                    {
                        myMergeField.Select();
                        winword.Selection.InlineShapes.AddPicture(QR_save_fileName, false, true);
                    }


                }

            }           

            document.SaveAs(ref temp_save_fileName);

            document.Close(ref missing, ref missing, ref missing);
            document = null;
            winword.Quit(ref missing, ref missing, ref missing);
            winword = null;


            string now_time = DateTime.Now.ToString("MMddyyyy_HHmmss");
            string file_name_pdf = @"C:\truck_check_in\" + Order_No + "_" + now_time + ".PDF"; 
            ConvertDocument_PDF(save_fileName, file_name_pdf);
            pictureBox1.Image = result;

            //https://social.msdn.microsoft.com/Forums/en-US/6634c718-67e9-403b-a301-704f9be545c8/print-a-word-document-from-c-using-printdialog?forum=csharplanguage
            //https://stackoverflow.com/questions/3197830/is-there-anyway-to-specify-a-printto-printer-when-spawning-a-process
            using (PrintDialog pd = new PrintDialog())
            {
                if (pd.ShowDialog() == DialogResult.OK)
                {
                    //pd.ShowDialog();
                    ProcessStartInfo info = new ProcessStartInfo(file_name_pdf);
                    info.Verb = "PrintTo";
                    info.Arguments = "\"" + pd.PrinterSettings.PrinterName + "\"";
                    info.CreateNoWindow = true;
                    info.WindowStyle = ProcessWindowStyle.Hidden;
                    Process process = Process.Start(info);
                    if (process.HasExited == false)
                    {
                        process.WaitForExit(10000);
                    }
                    process.Close();
                    //if (!process.WaitForExit(1000))
                    //{
                    //    process.Kill();

                    //}
                }             
            }
            //printDocument1.Dispose();
            //printPreviewDialog1.Dispose();
        }

        private static void ConvertDocument_PDF(string file_name_docx, string file_name_pdf)
        {
            try
            {
                var wordApp = new Word.Application();
                wordApp.Visible = false;
                object readOnly = true;
                var wordDocument = wordApp.Documents.Open(file_name_docx, ref readOnly);

                wordDocument.ExportAsFixedFormat(file_name_pdf, Word.WdExportFormat.wdExportFormatPDF);

                wordDocument.Close(Word.WdSaveOptions.wdDoNotSaveChanges,
                                   Word.WdOriginalFormat.wdOriginalDocumentFormat,
                                   false); //Close document

                //wordApp.ActiveDocument.PrintOut();
                wordApp.Quit(); //Important: When you forget this Word keeps running in the background
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
